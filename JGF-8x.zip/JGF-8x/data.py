from os.path import exists, join, basename
from os import makedirs, remove
from six.moves import urllib
import tarfile
from torchvision.transforms import Compose, CenterCrop, ToTensor

from dataset import DatasetFromFolderEval, DatasetFromFolder

def calculate_valid_crop_size(crop_size, upscale_factor):
    return crop_size - (crop_size % upscale_factor)


def input_transform():
    return Compose([
        ToTensor(),
    ])


def target_transform():
    return Compose([
        ToTensor(),
    ])

def input_rgb_transform():
    return Compose([
        ToTensor(),
    ])


def get_training_set(data_dir, dataset, hr, rgb, upscale_factor, patch_size, data_augmentation):
    hr_dir = join(data_dir, hr)
    lr_dir = join(data_dir, dataset)
    rgb_dir = join(data_dir, rgb)

    return DatasetFromFolder(hr_dir, lr_dir, rgb_dir, patch_size, upscale_factor, dataset, data_augmentation,
                             input_transform=input_transform(),
                             input_rgb_transform=input_rgb_transform(),
                             target_transform=target_transform())


def get_test_set(data_dir, dataset, hr, upscale_factor,patch_size):
    hr_dir = join(data_dir, hr)
    lr_dir = join(data_dir, dataset)

    return DatasetFromFolder(hr_dir, lr_dir,patch_size, upscale_factor, dataset, data_augmentation=False,
                             input_transform=input_transform(),
                             target_transform=target_transform())

def get_eval_set(lr_dir,rgb_dir):
    return DatasetFromFolderEval(lr_dir,rgb_dir,
                             input_transform=input_transform(),
                             input_rgb_transform = input_rgb_transform(),
                             target_transform=target_transform())

